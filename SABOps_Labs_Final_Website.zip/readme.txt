SABOps Labs Website — Bikash Bhandari
--------------------------------------------------
Upload instructions:
1. Unzip these files.
2. Upload all contents to your GitHub repo (sabops-labs-site).
3. Enable GitHub Pages (main branch, root).
4. Add your Formspree ID in audit.html action attribute.
5. Replace bikash.jpg with your portrait (same filename).